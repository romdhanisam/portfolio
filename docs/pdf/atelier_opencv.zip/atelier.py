import numpy as np
import cv2 as cv

import matplotlib
import matplotlib.pyplot as plt
matplotlib.use('agg')


img=cv.imread ("tulipes.jpg")
cv.namedWindow('image', cv.WINDOW_NORMAL)
cv.imshow('image',img)
cv.waitKey(0)
cv.destroyAllWindows()

filtred = cv.bilateralFilter(img, 20, 19, 19)


cv.namedWindow('image filtree', cv.WINDOW_NORMAL)
cv.imshow('image',filtred)
cv.waitKey(0)
cv.destroyAllWindows()

gray = cv.cvtColor(img, cv.COLOR_BGR2GRAY)
cv.namedWindow('image grise', cv.WINDOW_NORMAL)
cv.imshow('image',gray)
cv.waitKey(0)
cv.destroyAllWindows()


# ret,th=cv.threshold(gray,150,255,cv.THRESH_BINARY)
th=255.0*(gray>150.0) 
cv.namedWindow('image',cv.WINDOW_NORMAL)
cv.imshow('image',np.uint8(th))
cv.waitKey(0)
cv.destroyAllWindows()


hsv = cv.cvtColor(filtred, cv.COLOR_BGR2HSV_FULL)
# Déclaration des couleurs des courbes
color = ('r','g','b')
# Déclaration des noms des courbes.
labels = ('h','s','v')
#Pour col allant r à b et pour i allant de 0 au nombre de couleurs
for i,col in enumerate(color):
    # Hist prend la valeur de l'histogramme de hsv sur la canal i.
    hist = cv.calcHist([hsv],[i],None,[256],[0,256])
    # Plot de hist.
    plt.plot(hist,color = col,label=labels[i])
    plt.xlim([0,256])
#Affichage.
plt.show()
# Sauvegarde en pdf
plt.savefig('fig1.pdf')

# Extraction des canaux
h =  hsv[:,:,0]
s =  hsv[:,:,1]

cv.namedWindow('hue',cv.WINDOW_NORMAL)
cv.imshow('hue',np.uint8(h))
cv.waitKey(0)
cv.destroyAllWindows()

cv.namedWindow('saturation',cv.WINDOW_NORMAL)
cv.imshow('saturation',np.uint8(s))
cv.waitKey(0)
cv.destroyAllWindows()


ret,thh=cv.threshold(h,250,255,cv.THRESH_BINARY)

print(h)
thh=255*( ((h<15.0) | (h>245)) & (s>200.0))

cv.namedWindow('image seuillee h et v',cv.WINDOW_NORMAL)
cv.imshow('image seuillee h et v',np.uint8(thh))
cv.waitKey(0)
cv.destroyAllWindows()


erosion_shape = cv.MORPH_ELLIPSE

erosion_shape = cv.MORPH_CROSS
erosion_shape = cv.MORPH_RECT 

erosion_size = 15

element = cv.getStructuringElement(erosion_shape, (2 * erosion_size + 1, 2 * erosion_size + 1),(erosion_size, erosion_size))

print(element)

erosion_dst = cv.erode(np.uint8(255*thh) , element)
erosion_dst = cv.morphologyEx(np.uint8(255*thh) , cv.MORPH_OPEN, element) 


cv.namedWindow('image erosion',cv.WINDOW_NORMAL)
cv.imshow('image erosion',np.uint8(erosion_dst*255))
cv.waitKey(0)
cv.destroyAllWindows()

retval, labels = cv.connectedComponents(erosion_dst)
erosion_shape = cv.MORPH_CROSS

print(retval)

c=0

for i in range(retval):
    idcc = np.where(labels == i)
    if len(idcc[0])> 1000 :
        c=c+1
        cv.namedWindow('image',cv.WINDOW_NORMAL)
        cv.imshow('image',np.uint8((labels==i)*255))
        print('ok')
        print(np.mean(idcc, axis=1))
        cv.waitKey(500)
        cv.destroyAllWindows()

print(c)

