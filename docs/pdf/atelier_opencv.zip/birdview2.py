#import pickle
import numpy as np
import glob

import matplotlib
matplotlib.use('agg')
import matplotlib.pyplot as plt
import cv2 as cv

import matplotlib.image as mpimg

# critere d'arret de la recherche
criteria = (cv.TERM_CRITERIA_EPS + cv.TERM_CRITERIA_MAX_ITER, 30, 0.001)

# print(criteria)
# points de damier image réguliers sur lesquels recaller
objp = np.zeros((6 * 7, 3), np.float32)

objp[:, :2] = np.mgrid[0:7, 0:6].T.reshape(-1, 2)
# Arrays to store object points and image points from all the images.
objpoints = []  # 3d point in real world space
imgpoints = []  # 2d points in image plane.
images = glob.glob("right03.png")

# Lecture des images et détections de coins.
for fname in images:
    img = cv.imread(fname)
    gray = cv.cvtColor(img, cv.COLOR_BGR2GRAY)
    # Detections des points saillants
    ret, corners = cv.findChessboardCorners(gray, (7, 6), None)
    # Si on en trouve on les met dans une liste
    if ret == True:
        objpoints.append(objp)
        corners2 = cv.cornerSubPix(gray, corners, (11, 11), (-1, -1), criteria)
        imgpoints.append(corners2)
        # Affichage des points trouves pour verification
        cv.drawChessboardCorners(img, (7, 6), corners2, ret)
        cv.imshow("img", img)
        cv.waitKey(0)
cv.destroyAllWindows()


ret, mtx, dist, rvecs, tvecs = cv.calibrateCamera(
    objpoints, imgpoints, gray.shape[::-1], None, None
)

# Lescture d'une image de damier à recaller
img = cv.imread("right03.png")
# img = cv.imread('test_image2.png')
nx = 8  # the number of inside corners in x
ny = 6  # the number of inside corners in y


def corners_unwarp(img, nx, ny, mtx, dist):
    # suppression de distorsion
    undistorted = cv.undistort(img, mtx, dist, None, mtx)
    # conversion en niveaux de gris
    gray = cv.cvtColor(undistorted, cv.COLOR_BGR2GRAY)
    #  détection des points
    ret, corners = cv.findChessboardCorners(gray, (nx, ny), None)
    # si on trouve des points
    if ret == True:
        offset = 100  # offset for dst points
        img_size = (undistorted.shape[1], undistorted.shape[0])
        # affichage des points
        cv.drawChessboardCorners(undistorted, (8, 6), corners, ret)
        # définition des coins de l echiquier
        src = np.float32([corners[0], corners[nx - 1], corners[-1], corners[-nx]])
        # Définition des coins de l'échiquier sur l'image finale. 
        dst = np.float32(
            [
                [offset, offset],
                [img_size[0] - offset, offset],
                [img_size[0] - offset, img_size[1] - offset],
                [offset, img_size[1] - offset],
            ]
        )
        # Calcul de matrice de transformation
        M = cv.getPerspectiveTransform(src, dst)
        # test de la viewbird sur l'échiquier
        warped = cv.warpPerspective(undistorted, M, img_size, flags=cv.INTER_LINEAR)

    return warped, M


top_down, perspective_M = corners_unwarp(img, nx, ny, mtx, dist)

cv.imshow("img", top_down)

############################################################################################################

imgl = cv.imread("lignes.jpg")

undistortedl = cv.undistort(imgl, mtx, dist, None, mtx)
img_size = (undistortedl.shape[1], undistortedl.shape[0])
warpedl = cv.warpPerspective(
    undistortedl, perspective_M, img_size, flags=cv.INTER_LINEAR
)

imgl = cv.resize(imgl, (512, 512))

# traitement description de l'image : conversion et laplacien apres flou gaussien 
imgl = cv.GaussianBlur(imgl, (25, 25), 0)
ddepth = cv.CV_16S
src_gray = cv.cvtColor(imgl, cv.COLOR_BGR2GRAY)
imgl = cv.Laplacian(src_gray, ddepth, ksize=3)
imgl = cv.convertScaleAbs(imgl)


# normalisation et seuillage
imgl = imgl.astype(float)
#imgl2 = 255.0 * (imgl / np.max(imgl))
imgl = 255 * ((imgl / np.max(imgl)) > 0.75)


# enregistrement de l'hsitogramme
#fig, axs = plt.subplots()
#axs.hist(imgl2.ravel(), bins=256)
#plt.show()
#plt.savefig('fig1.pdf')


# affichage des points d'interet
cv.imshow("img", np.uint8(imgl))
cv.waitKey(0)
cv.destroyAllWindows()


x, y = np.where(imgl==255)

xx = x**2
var1 = np.ones_like(x)

X = np.stack((xx, x, var1), axis=1)


from sklearn import datasets, linear_model

ransac = linear_model.RANSACRegressor()
ransac.fit(X, y)
inlier_mask = ransac.inlier_mask_
outlier_mask = np.logical_not(inlier_mask)

# Predict data of estimated models
line_X = np.arange(x.min(), x.max())
line_XX = line_X**2
line_1 = np.ones_like(line_X)
llll = np.stack((line_XX, line_X, line_1), axis=1)


line_y_ransac = ransac.predict(llll)

# Compare estimated coefficients
print( ransac.estimator_.coef_)
print( ransac.estimator_.intercept_)
print(-ransac.estimator_.coef_[1]/(2*ransac.estimator_.coef_[0]))

plt.close('all')
lw = 2
plt.scatter(
    y[inlier_mask], x[inlier_mask], color="yellowgreen", marker=".", label="Inliers"
)
plt.scatter(
    y[outlier_mask], x[outlier_mask], color="gold", marker=".", label="Outliers"
)
plt.plot(
    line_y_ransac,
    line_X,
    color="cornflowerblue",
    linewidth=lw,
    label="RANSAC regressor",
)
plt.show()
plt.savefig('fig2.pdf')

